sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";
	
	var wfTaskId;
	return Controller.extend("Zapprovers_1.Zapprovers_1.controller.View1", {
		
			onInit: function () {
				
			},
			onAfterRendering : function(){
			wfTaskId = sap.ui.getCore()._sTaskId;
			},
			
			onPress: function(oEvent){
				var baseUrl ="https://invoiceprocessors-m7qnk0ke3x.dispatcher.us3.hana.ondemand.com/index.html?hc_reset#/Invoice/";
				var oInvoiceGUID = this.getView().byId("idGUID").getText();
				// sap.ui.getCore().invoiceGlobal = oInvoiceGUID;
				var mParameter = "?TaskID="+ wfTaskId + "&role=" + "approver";
				// var mParameter = "?role=" + "approver";
    			sap.m.URLHelper.redirect(baseUrl + oInvoiceGUID + mParameter, true);
    			// sap.m.URLHelper.redirect(baseUrl + oInvoiceGUID , true);
			}

	});
	

	
});