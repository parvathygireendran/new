sap.ui.define([
	"Zapprovers_1/Zapprovers_1/test/unit/controller/View1.controller"
], function () {
	"use strict";
});