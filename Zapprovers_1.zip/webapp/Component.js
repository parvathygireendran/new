sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Zapprovers_1/Zapprovers_1/model/models",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/TextArea",
	"sap/m/Button",
	"sap/m/MessageItem",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/MessagePopover",
	// "sap/m/MessageItem",
	"sap/m/MessageBox",
	"sap/m/MessageView",
	"sap/ui/core/BusyIndicator"
], function (UIComponent, Device, models, JSONModel, ODataModel, MessageToast, MessagePopover, MessageItem, MessageBox,
MessageView,BusyIndicator) {
	"use strict";
	
	// var SAVE_INVOICE_SERVICE = "/HDB_SCP/com/deloitte/apps/invoiceprocessor/services/saveInvoice/saveInvoice.xsjs";
	var POST_INVOICE_SERVICE = "/html5apps/zapprovers1/HDB_SCP/com/deloitte/apps/invoiceprocessor/services/postInvoice/postInvoice.xsjs";
	// var CAPTURE_REJECTCOMMENT_SERVICE = "/HDB_SCP/com/deloitte/apps/invoiceprocessor/services/workflowResponse/workflowResponse.xsjs";
	var CAPTURE_REJECTCOMMENT_SERVICE = "/html5apps/zapprovers1/HDB_SCP/com/deloitte/apps/invoiceprocessor/services/workflowResponse/workflowResponse.xsjs";
	
		var oMessageTemplate = new MessageItem({
		type: '{type}',
		title: '{title}',
		subtitle: '{description}',
		description: '{description}'
	});
	
/*	var oMessageTemplate = new MessagePopoverItem({
		type: '{type}',
		title: '{title}',
		subtitle: '{description}',
		description: '{description}'
	});*/

/*	var oMessagePopover = new MessagePopover({
		items: {
			path: '/',
			template: oMessageTemplate
		},
		initiallyExpanded: true
	});*/
		
	return UIComponent.extend("Zapprovers_1.Zapprovers_1.Component", {

		metadata: {
			manifest: "json"
		},
		init: function () {
			UIComponent.prototype.init.apply(this, arguments);
			this.setModel(models.createDeviceModel(), "device");
			this._oApp = this.getRootControl();

			// get task data
			// var oStartupParameter = this.getComponentData().startupParameters;
			// var taskModel = oStartupParameter.taskModel;
			// var taskData = taskModel.getData();
			// var sTaskId = taskData.InstanceID;
			// sap.ui.getCore()._sTaskId = sTaskId;
			// // initialize model
			// var contextModel = new sap.ui.model.json.JSONModel("/bpmworkflowruntime/rest/v1/task-instances/" + sTaskId + "/context");
			// contextModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			// this.setModel(contextModel);
			
			// get task id
			var oStartupParameter = this.getComponentData().startupParameters;
			var oTaskModel = oStartupParameter.taskModel;
			var oTaskData = oTaskModel.getData();
			var sTaskId = oTaskData.InstanceID;
			sap.ui.getCore()._sTaskId = sTaskId;
			var oVendorModel = new sap.ui.model.json.JSONModel();
			var jsonModel = new sap.ui.model.json.JSONModel();
			this.setModel(oVendorModel);
			this._oApp.setBusy(true);

			// get task data
			$.ajax({
				type: "GET",
				url: "/bpmworkflowruntime/rest/v1/task-instances/" + sTaskId + "/context",
				contentType: "application/json",
				dataType: "json",
				async: false,
				success: function (result, xhr, data) {
					var oProcessContext = {};
					oProcessContext.context = data.responseJSON;
					// save vendor number for latter use in detail view
					// this.getComponentData().payeeVendorNumber = oProcessContext.context.payeeVendorNumber;
					// save InvoiceGUID for latter use in detail view
					sap.ui.getCore().invoiceGUID = oProcessContext.context.invoiceGUID;
					
					oProcessContext.context.task = {};
					oProcessContext.context.task.Title = oTaskData.TaskTitle;
					oProcessContext.context.task.Priority = oTaskData.Priority;
					oProcessContext.context.task.Status = oTaskData.Status;
					if (oTaskData.Priority === "HIGH") {
						oProcessContext.context.task.PriorityState = "Warning";
					} else if (oTaskData.Priority === "VERY HIGH") {
						oProcessContext.context.task.PriorityState = "Error";
					} else {
						oProcessContext.context.task.PriorityState = "Success";
					}
					oProcessContext.context.task.CreatedOn = oTaskData.CreatedOn.toDateString();
					// get task description and add it to the model
					oStartupParameter.inboxAPI.getDescription("NA", oTaskData.InstanceID).done(function (dataDescr) {
						this._oApp.setBusy(false);
						oProcessContext.context.task.Description = dataDescr.Description;
						oVendorModel.setProperty("/context/task/Description", dataDescr.Description);
					}.bind(this)).
					fail(function (errorText) {
						this._oApp.setBusy(false);
						MessageBox.error(errorText, {
							title: "Error"
						});
					}.bind(this));
					// model for vendor details
					oVendorModel.setData(oProcessContext);
					this.setModel(oVendorModel);
				}.bind(this)
			});

			// Adding Approve/Reject Buttons
			oStartupParameter.inboxAPI.addAction({
				action: "Approve",
				label: "Approve"
			}, function (button) {
				  //var invoiceNumber1 = sap.ui.getCore().invoiceNumber1;
				
			
				var currentViewController = this;
			
				var servicePayloadJSON = JSON.stringify({
					invoiceGUID: sap.ui.getCore().invoiceGUID
				});
			
				$.post({
					url: POST_INVOICE_SERVICE,
					contentType: 'application/json',
					// dataType: "application/json", 
					dataType: 'json',
					// async : false,
					data: servicePayloadJSON
				}).done(function (responseData, textStatus, xhr) {
	
					if (responseData.postingErrors) {
						currentViewController._displayPostingErrors(responseData.postingErrors);
					}
	
					if (responseData.postedInvoice) {
	
						// Update the model with the posted invoice number
						// var currentViewModel = currentViewController.getView().getModel("invoiceDetails");
						// currentViewModel.setProperty("/postedInvoice", responseData.postedInvoice);
						// currentViewModel.refresh();
	
						sap.m.MessageBox.information(
 						"Invoice: " + responseData.postedInvoice + " successfully posted"
						);
						// sap.ui.getCore().invoiceSAP = responseData.postedInvoice;
						currentViewController._completeApproval(sTaskId, true);
					}
	
				}).fail(function (xhr, textStatus, error) {
	
					// Display an error message box with the error message
					MessageBox.error("Invoice Posting Failed: " + error.toString());
	
				});

			}, this); //End of Approve
			
			// Adding Approve/Reject Buttons
			oStartupParameter.inboxAPI.addAction({
				action: "Reject",
				label: "Reject"
			}, /*function (button) {
				this._completeRejection(sTaskId, false);*/
				function(button) {
				/*jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.information(
 							"Invoice has been rejected"
				  );*/
				var currentViewController = this;
				var sText;  
				var dialog = new sap.m.Dialog({
				title: 'Reject',
				type: 'Message',
				content: [
					new sap.m.Label({ text: 'Are you sure you want to reject the invoice?', labelFor: 'rejectDialogTextarea'}),
					new sap.m.TextArea('rejectDialogTextarea', {
						width: '100%',
						placeholder: 'Add note (optional)'
					})
				],
				beginButton: new sap.m.Button({
					text: 'Reject',
					press: function () {
						sText = sap.ui.getCore().byId('rejectDialogTextarea').getValue();
						// sap.m.MessageToast.show('Note is: ' + sText);
						currentViewController._postComments(sText);
						// currentViewController._completeApproval(sTaskId, true);
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
				});

			dialog.open();	
			
			}, this); //End of Reject
			
		},
		
		// POST call to save reject comments 
		_postComments: function (sText) {
				
				var currentViewController = this;
				var serviceRejPayloadJSON = JSON.stringify({
					invoiceGUID: sap.ui.getCore().invoiceGUID,
					responseType: "Rejected",
					comments:sText
				});
			
				$.ajax({
					type: 'POST', //GET or POST or PUT or DELETE verb 
					async : false,
					data: serviceRejPayloadJSON, //Data sent to server
					url: CAPTURE_REJECTCOMMENT_SERVICE, // Location of the service  
					contentType: 'application/json', 
					dataType: 'json', //Expected data format from server
					
					success: function(responseData, textStatus, xhr){ //On Successfull service call 
						if (textStatus === "success") {
						sap.m.MessageBox.information(
 						"The invoice got rejected"
						);
						currentViewController._completeApproval(sap.ui.getCore()._sTaskId, true);
						}
					},
					error: function (xhr) { 
						// console.log(xhr.responseText); 
						MessageBox.error(xhr.responseText);
					} // When Service call fails
				});

			
			
			
		},

		_displayPostingErrors: function (postingErrorsJSON) {

			var oPostingErrorTemplate = new sap.m.MessagePopoverItem({
				type: '{type}',
				title: '{title}',
				description: '{description}',
				subtitle: '{subtitle}',
				counter: '{counter}',
				markupDescription: '{markupDescription}'
			});

			var postingErrors = postingErrorsJSON.map(function (postingError) {
				return {
					Error: postingError.errorMessage
				};
			});

	    	// sap.m.MessageBox.error(JSON.stringify(postingErrors.errorMessage));
	    	sap.m.MessageBox.error("Error: "+ postingErrorsJSON[0].errorMessage);
						
			var oPostingErrorsMessageView = new MessageView({
			showDetailsPageHeader: false,
			itemSelect: function () {
			// oBackButton.setVisible(true);
			},
				items: {
					path: "",
					template: oMessageTemplate
			}
			});		
			oPostingErrorsMessageView.setModel(new JSONModel(postingErrorsJSON[0]));

/*		var oPostingErrorsMessageView = new MessageBox({
				showDetailsPageHeader: false,
				itemSelect: function () {
					oBackButton.setVisible(true);
				},
				items: {
					path: "/",
					template: oMessageTemplate
				}
			});

		var oBackButton = new sap.m.Button({
				icon: sap.ui.core.IconPool.getIconURI("nav-back"),
				visible: false,
				press: function () {
					oPostingErrorsMessageView.navigateBack();
					this.setVisible(false);
				}
			});

		oPostingErrorsMessageView.setModel(new JSONModel(postingErrors));

			var oPostingErrorsDialog = new sap.m.Dialog({
				resizable: true,
				content: oPostingErrorsMessageView,
				state: 'Error',

				beginButton: new sap.m.Button({
					press: function () {
						this.getParent().close();
					},
					text: "Close"
				}),

				customHeader: new sap.m.Bar({
					contentMiddle: [
						new sap.m.Text({
							text: "Posting Errors"
						})
					],
				contentLeft: [oBackButton]
				}),
				contentHeight: "300px",
				contentWidth: "500px",
				verticalScrolling: false
			});

			oPostingErrorsDialog.open();*/
		},

	
		
		_completeApproval: function (sTaskId, bApprovalStatus) {
			var that = this;
			var sWorkflowToken = this._fetchToken();
			var fnRemoveFromTaskList = function () {
				// remove task from the approver 1 list
				return new Promise(function (resolve, reject) {
					$.ajax({
						url: "/bpmworkflowruntime/rest/v1/task-instances/" + sTaskId,
						method: "PATCH",
						contentType: "application/json",
						async: false,
						data: "{\"status\": \"COMPLETED\", \"context\": {\"approved\":\"" +
							bApprovalStatus + "\"}}",
						headers: {
							"X-CSRF-Token": sWorkflowToken
						},
						success: function () {
							resolve();
							// that.getComponentData().startupParameters.inboxAPI.updateTask("NA", sTaskId);
						}
					});
				});
			};
			
			var fnRefreshTask = function () {
				this.getComponentData().startupParameters.inboxAPI.updateTask("NA", sTaskId);
			}.bind(this);
			
			fnRemoveFromTaskList().then(fnRefreshTask());
		},

		_fetchToken: function () {
			var sToken;
			$.ajax({
				url: "/bpmworkflowruntime/rest/v1/xsrf-token",
				method: "GET",
				async: false,
				headers: {
					"X-CSRF-Token": "Fetch"
				},
				success: function (result, xhr, data) {
					sToken = data.getResponseHeader("X-CSRF-Token");
				}
			});
			return sToken;
		}

	});
});